"""Version of zcatalyst SDK"""

__version__ = '0.0.1'
