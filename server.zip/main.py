import json
import zcatalyst_sdk
import logging
from flask import Request, make_response, jsonify


def handler(request: Request):
    if request.path == '/':
        app = zcatalyst_sdk.initialize()
        db = app.datastore()
        table_instance = db.table('Blog')
        table_instance.insert_row({
            'ScrapInput':"Hello, this is Vaishnavi",
            'ScrapDate': "2023-03-26 10:03:04",
            'URL' : "https://blog.medium.com/what-were-reading-where-do-you-get-your-big-questions-answered-8a25606ce00",
            'Type' : "Blog",
            'ScrapOutput' : "Just discovered the power of @Medium for learning online! From AI to banking, it is my go-to for answers. Recently read 'Power Laws in Culture' by Doug Shapiro, a must-read on why power laws are so prevalent in the culture industry. What is your favorite Medium story for learning? #onlinelearning #Medium"

        })
        return "Data inserted successfully"
    else:
        return 'unknown path'